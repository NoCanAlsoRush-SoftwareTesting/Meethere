module.exports = {
  presets: [
    '@vue/app',
  ],
  "env": {
    "test": {
      "plugins": ["istanbul"]
    }
  }
}
