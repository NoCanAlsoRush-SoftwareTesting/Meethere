import * as api from './api'
import  config from './config'
import request from './request'

export default {
    api,
    config,
    request
}