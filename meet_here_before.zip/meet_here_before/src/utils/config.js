export default {
    BASE_URL: '/api',
    DEVELOPMENT: false,
    REQUEST_TIMEOUT: 5000

}