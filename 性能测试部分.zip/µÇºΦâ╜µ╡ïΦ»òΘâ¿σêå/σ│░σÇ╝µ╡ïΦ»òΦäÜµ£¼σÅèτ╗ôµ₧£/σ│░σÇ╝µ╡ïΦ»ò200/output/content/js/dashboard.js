/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 97.14191367519139, "KoPercent": 2.8580863248086064};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9338101389745268, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9310991695163654, 500, 1500, "browse-stadium-72"], "isController": false}, {"data": [0.9314018728129337, 500, 1500, "browse-stadium-73"], "isController": false}, {"data": [0.8729105500097867, 500, 1500, "browse-site"], "isController": true}, {"data": [0.948621750288972, 500, 1500, "logout-80"], "isController": false}, {"data": [0.9484646768305777, 500, 1500, "login"], "isController": true}, {"data": [0.9965645129806754, 500, 1500, "home"], "isController": true}, {"data": [0.9289293403797221, 500, 1500, "browse-site-77"], "isController": false}, {"data": [0.948621750288972, 500, 1500, "logout"], "isController": true}, {"data": [0.9484646768305777, 500, 1500, "login-65"], "isController": false}, {"data": [0.9283406438474191, 500, 1500, "reserve-79"], "isController": false}, {"data": [0.9965645129806754, 500, 1500, "login-46"], "isController": false}, {"data": [0.8370867788790491, 500, 1500, "browse-stadium"], "isController": true}, {"data": [0.9296011579915107, 500, 1500, "browse-site-78"], "isController": false}, {"data": [0.9318736694076056, 500, 1500, "browse-stadium-69"], "isController": false}, {"data": [0.9283406438474191, 500, 1500, "reserve"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 460308, 13156, 2.8580863248086064, 541.3064122283398, 0, 34429, 593.7000000000044, 2543.0, 16144.980000000003, 99.35441259316339, 53.1802567362006, 52.82100448023307], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["browse-stadium-72", 51175, 1853, 3.620908646800195, 619.1836248168064, 1, 34140, 439.0, 7083.0, 20260.99, 11.045942270139177, 4.4258512238790715, 5.81141851314764], "isController": false}, {"data": ["browse-stadium-73", 51153, 1839, 3.595097061755909, 577.5710124528408, 1, 27309, 437.0, 7057.950000000001, 20220.0, 11.04120079776901, 6.253578542595706, 6.122789418916687], "isController": false}, {"data": ["browse-site", 51090, 2668, 5.222156977882169, 1194.6585437463268, 2, 52244, 7056.9000000000015, 13745.0, 26534.99, 11.027583420247412, 8.405232271578578, 11.69134743696373], "isController": true}, {"data": ["logout-80", 51043, 952, 1.865094136316439, 596.6133652018898, 1, 34254, 428.0, 7039.0, 20214.0, 11.0176312751101, 3.5778768129780674, 5.527219168297054], "isController": false}, {"data": ["login", 51227, 1006, 1.9638081480469283, 610.7852890077475, 1, 27329, 344.0, 7058.0, 20167.99, 11.057268912641813, 4.690195997818852, 5.817949170184097], "isController": true}, {"data": ["home", 51230, 20, 0.03903962521959789, 48.875268397424, 0, 27331, 91.0, 140.0, 275.9900000000016, 11.0742928762444, 16.951365796804343, 4.884116052882504], "isController": true}, {"data": ["browse-site-77", 51090, 1879, 3.6778234488158152, 575.8952436876143, 1, 33898, 441.0, 7065.950000000001, 20231.950000000008, 11.027588180773877, 4.833285677952227, 5.737845936887401], "isController": false}, {"data": ["logout", 51043, 952, 1.865094136316439, 596.6134435671871, 1, 34254, 428.0, 7039.0, 20214.0, 11.0176312751101, 3.5778768129780674, 5.527219168297054], "isController": true}, {"data": ["login-65", 51227, 1006, 1.9638081480469283, 610.785152361063, 1, 27329, 344.0, 7058.0, 20167.99, 11.057268912641813, 4.690195997818852, 5.817949170184097], "isController": false}, {"data": ["reserve-79", 51068, 1945, 3.808647293804339, 607.0560037596925, 1, 34094, 443.0, 7080.950000000001, 20248.99, 11.022944249389472, 3.713074145855647, 7.03751099376425], "isController": false}, {"data": ["login-46", 51230, 20, 0.03903962521959789, 48.87520983798571, 0, 27331, 91.0, 140.0, 275.9900000000016, 11.074460452416462, 16.95162230482912, 4.884189959314383], "isController": false}, {"data": ["browse-stadium", 51153, 3370, 6.588078900553242, 1805.0465661838066, 4, 60176, 13656.0, 20436.95, 27445.950000000008, 11.04118173215729, 15.859726652278537, 17.859389277890244], "isController": true}, {"data": ["browse-site-78", 51123, 1878, 3.673493339592747, 622.5740664671536, 1, 34429, 438.0, 7083.0, 20286.0, 11.034694436548078, 3.574233340682889, 5.957344205603664], "isController": false}, {"data": ["browse-stadium-69", 51199, 1784, 3.4844430555284283, 614.0642981308255, 1, 33157, 444.0, 7064.950000000001, 20247.850000000024, 11.051249009793066, 5.186976304982117, 5.933104902778947], "isController": false}, {"data": ["reserve", 51068, 1945, 3.808647293804339, 607.0560429231617, 1, 34094, 443.0, 7080.950000000001, 20248.99, 11.022946628674468, 3.713074947316799, 7.03751251279981], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400\/Bad Request", 5545, 42.14806932198236, 1.2046282054624295], "isController": false}, {"data": ["500\/Internal Server Error", 7460, 56.704165399817576, 1.6206539968890394], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 151, 1.147765278200061, 0.032804122457137395], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 460308, 13156, "500\/Internal Server Error", 7460, "400\/Bad Request", 5545, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 151, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["browse-stadium-72", 51175, 1853, "500\/Internal Server Error", 965, "400\/Bad Request", 865, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 23, null, null, null, null], "isController": false}, {"data": ["browse-stadium-73", 51153, 1839, "400\/Bad Request", 927, "500\/Internal Server Error", 900, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 12, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["logout-80", 51043, 952, "500\/Internal Server Error", 925, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 27, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["browse-site-77", 51090, 1879, "400\/Bad Request", 981, "500\/Internal Server Error", 881, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 17, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["login-65", 51227, 1006, "500\/Internal Server Error", 1006, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["reserve-79", 51068, 1945, "400\/Bad Request", 1007, "500\/Internal Server Error", 921, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 17, null, null, null, null], "isController": false}, {"data": ["login-46", 51230, 20, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 20, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["browse-site-78", 51123, 1878, "400\/Bad Request", 967, "500\/Internal Server Error", 897, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 14, null, null, null, null], "isController": false}, {"data": ["browse-stadium-69", 51199, 1784, "500\/Internal Server Error", 965, "400\/Bad Request", 798, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 21, null, null, null, null], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
