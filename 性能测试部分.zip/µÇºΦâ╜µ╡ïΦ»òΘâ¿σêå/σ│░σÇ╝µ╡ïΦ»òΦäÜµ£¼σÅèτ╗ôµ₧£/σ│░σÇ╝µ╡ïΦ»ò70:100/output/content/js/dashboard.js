/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.31051796541021, "KoPercent": 0.6894820345897893};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9564279990043287, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9665871121718377, 500, 1500, "browse-30"], "isController": false}, {"data": [0.9712467760677946, 500, 1500, "logout-43"], "isController": false}, {"data": [0.9724372092364558, 500, 1500, "login-22"], "isController": false}, {"data": [0.8540334947038137, 500, 1500, "browse-26"], "isController": false}, {"data": [0.966559934260394, 500, 1500, "browse-37"], "isController": false}, {"data": [0.9679181129135085, 500, 1500, "browse-38"], "isController": false}, {"data": [0.9968950256682598, 500, 1500, "login-2"], "isController": false}, {"data": [0.9663334490502944, 500, 1500, "reserve-42"], "isController": false}, {"data": [0.967022926715254, 500, 1500, "browse-29"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1270664, 8761, 0.6894820345897893, 338.71353323931015, 0, 33450, 116.0, 127.0, 1033.0, 166.245622142184, 89.11640249701601, 87.94563109938348], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["browse-30", 141203, 1229, 0.8703781081138503, 382.2808509734192, 1, 33267, 204.0, 252.0, 17651.0, 18.47744870065206, 10.56533393545429, 10.247803620920687], "isController": false}, {"data": ["logout-43", 282264, 1294, 0.4584360740299861, 378.5160204631147, 0, 33267, 195.0, 234.0, 11925.650000000056, 36.93635915984779, 11.948498441356412, 18.538558930722868], "isController": false}, {"data": ["login-22", 282446, 1290, 0.4567244712263583, 359.6890980930867, 1, 33031, 155.0, 181.0, 14232.990000000002, 36.96010751231857, 15.803641107137413, 19.453233263929917], "isController": false}, {"data": ["browse-26", 282373, 4906, 1.7374182375793719, 1136.5537321202848, 1, 74187, 1050.0, 2432.9500000000007, 26710.81000000003, 36.94415417338121, 49.48134962808307, 59.38898074862307], "isController": false}, {"data": ["browse-37", 141163, 1263, 0.8947103702811643, 378.60296961668786, 1, 33450, 202.0, 245.0, 14395.88000000002, 18.469058050956562, 8.125993257247668, 9.612104207427214], "isController": false}, {"data": ["browse-38", 141170, 1229, 0.8705815683218814, 370.4176099737841, 1, 33383, 202.0, 249.0, 16074.970000000005, 18.473120739123733, 5.94810619638287, 9.97526102937857], "isController": false}, {"data": ["login-2", 282450, 26, 0.009205169056470171, 41.533269605239916, 0, 33077, 77.0, 83.0, 109.0, 36.95363858909713, 56.55284559412083, 15.37052159547351], "isController": false}, {"data": ["reserve-42", 282298, 2502, 0.8862974587138414, 379.8696023351152, 1, 33385, 196.0, 238.95000000000073, 14339.990000000002, 36.93443822556962, 12.393086246203987, 23.58559031623325], "isController": false}, {"data": ["browse-29", 141189, 1205, 0.8534659215661277, 369.95407574244723, 1, 33385, 202.0, 250.0, 16102.890000000018, 18.475609444912553, 7.4157819831483955, 9.723618788662604], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400\/Bad Request", 3863, 44.09314005250542, 0.3040142791485397], "isController": false}, {"data": ["500\/Internal Server Error", 4767, 54.411596849674694, 0.37515818501193077], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 131, 1.4952630978198835, 0.010309570429318845], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1270664, 8761, "500\/Internal Server Error", 4767, "400\/Bad Request", 3863, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 131, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["browse-30", 141203, 1229, "400\/Bad Request", 644, "500\/Internal Server Error", 566, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 19, null, null, null, null], "isController": false}, {"data": ["logout-43", 141132, 647, "500\/Internal Server Error", 634, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 13, null, null, null, null, null, null], "isController": false}, {"data": ["login-22", 141223, 645, "500\/Internal Server Error", 645, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["browse-26", 141210, 1279, "400\/Bad Request", 644, "500\/Internal Server Error", 618, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 17, null, null, null, null], "isController": false}, {"data": ["browse-37", 141163, 1263, "400\/Bad Request", 644, "500\/Internal Server Error", 602, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 17, null, null, null, null], "isController": false}, {"data": ["browse-38", 141170, 1229, "400\/Bad Request", 644, "500\/Internal Server Error", 572, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 13, null, null, null, null], "isController": false}, {"data": ["login-2", 141225, 13, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 13, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["reserve-42", 141149, 1251, "400\/Bad Request", 643, "500\/Internal Server Error", 588, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 20, null, null, null, null], "isController": false}, {"data": ["browse-29", 141189, 1205, "400\/Bad Request", 644, "500\/Internal Server Error", 542, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8080 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 19, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
