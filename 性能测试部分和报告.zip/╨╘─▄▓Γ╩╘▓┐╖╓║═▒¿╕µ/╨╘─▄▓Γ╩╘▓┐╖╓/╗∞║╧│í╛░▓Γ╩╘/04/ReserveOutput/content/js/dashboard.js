/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.95846829429057, "KoPercent": 1.0415317057094302};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9727170352616163, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9844241341085447, 500, 1500, "login-75"], "isController": false}, {"data": [0.9757960413080895, 500, 1500, "browse-87"], "isController": false}, {"data": [0.9751880295410267, 500, 1500, "browse-88"], "isController": false}, {"data": [0.9802205149125193, 500, 1500, "logout-96"], "isController": false}, {"data": [0.9885697803316517, 500, 1500, "login-56"], "isController": false}, {"data": [0.9367782909930716, 500, 1500, "browse-79"], "isController": false}, {"data": [0.9745037839307563, 500, 1500, "reserve-95"], "isController": false}, {"data": [0.9748155023316883, 500, 1500, "browse-82"], "isController": false}, {"data": [0.9749351869672029, 500, 1500, "browse-83"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 794983, 8280, 1.0415317057094302, 236.0693423633011, 0, 33438, 72.0, 83.0, 26152.0, 272.1046081472942, 163.4514739106213, 143.9409982020175], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["login-75", 88406, 589, 0.666244372553899, 240.0929801144708, 1, 27752, 57.0, 65.0, 26126.99, 30.259778310824874, 12.893029798125527, 15.954116130875612], "isController": false}, {"data": ["browse-87", 88312, 1147, 1.2988042395144488, 253.30755729685703, 1, 27764, 73.0, 85.0, 26135.99, 30.227914201355585, 12.601459429288614, 15.729197846733467], "isController": false}, {"data": ["browse-88", 88284, 1185, 1.3422590729917085, 268.1503783244994, 1, 27765, 76.0, 92.0, 26140.0, 30.218381924831927, 22.560224856693388, 16.31389547349799], "isController": false}, {"data": ["logout-96", 176496, 1274, 0.7218293899011876, 270.73858897652656, 0, 27768, 71.0, 93.0, 26123.0, 60.41249146418896, 19.583679588116098, 30.312141132255014], "isController": false}, {"data": ["login-56", 176812, 631, 0.3568762301201276, 150.2076329660885, 0, 27768, 75.0, 85.0, 1079.9800000000032, 60.5173402243576, 105.51616233624547, 41.11743945574884], "isController": false}, {"data": ["browse-79", 176664, 4677, 2.647398451297378, 779.882335959784, 2, 46859, 773.9000000000015, 1326.0, 26756.0, 60.46925075071427, 98.64252046152026, 97.15868981332603], "isController": false}, {"data": ["reserve-95", 176536, 2382, 1.3492998595187384, 267.86205646440555, 1, 33075, 76.0, 142.0000000000291, 26131.0, 60.42579001305479, 20.295609927224874, 38.5816885388806], "isController": false}, {"data": ["browse-82", 88348, 1152, 1.3039344410739349, 262.4641304839971, 1, 27757, 74.0, 88.0, 26130.0, 30.24032963561204, 12.235825602257414, 15.91117593358221], "isController": false}, {"data": ["browse-83", 88331, 1170, 1.3245632903510658, 262.5469087862711, 1, 33438, 74.0, 90.0, 26138.0, 30.23432448630811, 22.543219798235317, 16.7652503269244], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400\/Bad Request", 3395, 41.0024154589372, 0.42705315711153574], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 234, 2.8260869565217392, 0.029434591683092596], "isController": false}, {"data": ["500\/Internal Server Error", 4651, 56.171497584541065, 0.5850439569148019], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 794983, 8280, "500\/Internal Server Error", 4651, "400\/Bad Request", 3395, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 234, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["login-75", 88406, 589, "500\/Internal Server Error", 589, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["browse-87", 88312, 1147, "400\/Bad Request", 566, "500\/Internal Server Error", 555, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 26, null, null, null, null], "isController": false}, {"data": ["browse-88", 88284, 1185, "500\/Internal Server Error", 591, "400\/Bad Request", 566, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 28, null, null, null, null], "isController": false}, {"data": ["logout-96", 88248, 637, "500\/Internal Server Error", 602, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 35, null, null, null, null, null, null], "isController": false}, {"data": ["login-56", 88406, 21, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 21, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["browse-79", 88380, 1188, "500\/Internal Server Error", 586, "400\/Bad Request", 565, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 37, null, null, null, null], "isController": false}, {"data": ["reserve-95", 88268, 1191, "500\/Internal Server Error", 601, "400\/Bad Request", 566, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 24, null, null, null, null], "isController": false}, {"data": ["browse-82", 88348, 1152, "400\/Bad Request", 566, "500\/Internal Server Error", 551, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 35, null, null, null, null], "isController": false}, {"data": ["browse-83", 88331, 1170, "500\/Internal Server Error", 576, "400\/Bad Request", 566, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 28, null, null, null, null], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
