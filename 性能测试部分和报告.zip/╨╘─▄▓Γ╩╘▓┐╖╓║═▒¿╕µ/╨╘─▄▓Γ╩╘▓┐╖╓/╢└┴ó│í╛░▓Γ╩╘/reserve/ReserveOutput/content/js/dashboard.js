/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.46800459679906, "KoPercent": 0.5319954032009417};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9840354396522902, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9986557935298862, 500, 1500, "reserve-384"], "isController": false}, {"data": [0.9866490149441278, 500, 1500, "reserve-416"], "isController": false}, {"data": [0.9873181899802478, 500, 1500, "reserve-417"], "isController": false}, {"data": [0.9888599991034205, 500, 1500, "reserve-407"], "isController": false}, {"data": [0.9873181899802478, 500, 1500, "reserve"], "isController": true}, {"data": [0.9881245798790051, 500, 1500, "reserve-403"], "isController": false}, {"data": [0.9868114121657994, 500, 1500, "reserve-415"], "isController": false}, {"data": [0.9986557935298862, 500, 1500, "login"], "isController": true}, {"data": [0.9871743127494507, 500, 1500, "reserve-410"], "isController": false}, {"data": [0.9871720116618076, 500, 1500, "reserve-411"], "isController": false}, {"data": [0.9275905398734461, 500, 1500, "browse"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 178385, 949, 0.5319954032009417, 175.49887602657267, 0, 27077, 35.0, 40.0, 1242.0, 279.1356707173952, 174.93258949493554, 148.60854842233618], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["reserve-384", 22318, 7, 0.03136481763598889, 21.809212295008557, 0, 26713, 15.0, 17.0, 23.0, 36.424051820794574, 55.75109816443539, 15.14399841813728], "isController": false}, {"data": ["reserve-416", 22283, 120, 0.5385271283040883, 187.2827267423604, 4, 27067, 40.0, 47.0, 1083.9600000000064, 34.871729063738755, 26.113589563031397, 18.82855334329553], "isController": false}, {"data": ["reserve-417", 22276, 143, 0.6419464894954211, 207.08982761716678, 1, 27076, 37.0, 43.0, 1239.0, 34.86126543451385, 11.69834120545705, 22.254752739675112], "isController": false}, {"data": ["reserve-407", 22307, 134, 0.6007082978437261, 195.87403057336357, 3, 27077, 38.0, 43.0, 1071.6400000000576, 34.908359102119505, 16.590958122038415, 18.741880216027457], "isController": false}, {"data": ["reserve", 22276, 143, 0.6419464894954211, 207.08991739989293, 1, 27076, 37.0, 43.0, 1239.0, 34.86126543451385, 11.69834120545705, 22.254752739675112], "isController": true}, {"data": ["reserve-403", 22315, 144, 0.6453058480842483, 201.19560833519984, 1, 27062, 27.0, 31.0, 1232.9900000000016, 34.92022258805561, 12.362450703940203, 18.41074941160638], "isController": false}, {"data": ["reserve-415", 22292, 132, 0.5921406782702314, 193.78342006100823, 2, 27065, 37.0, 42.0, 1093.0, 34.88559521629789, 14.555436787366412, 18.149102671955372], "isController": false}, {"data": ["login", 22318, 7, 0.03136481763598889, 21.80934671565558, 0, 26713, 15.0, 17.0, 23.0, 36.41995052187025, 55.74482066625761, 15.14229322441726], "isController": true}, {"data": ["reserve-410", 22299, 129, 0.578501278084219, 192.58123682676293, 2, 27063, 38.0, 44.0, 1079.0, 34.896167509115664, 14.098616964621055, 18.363916937919594], "isController": false}, {"data": ["reserve-411", 22295, 140, 0.6279434850863422, 204.5321372505044, 2, 27076, 38.0, 43.0, 1130.6700000000528, 34.89034463115921, 26.07021867693685, 19.35133993614261], "isController": false}, {"data": ["browse", 22283, 764, 3.4286227168693624, 1146.4334245837651, 20, 30527, 646.7000000000044, 1368.0, 26974.980000000003, 34.87020110261382, 109.72967587588239, 111.76499064935831], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400\/Bad Request", 12, 1.2644889357218125, 0.006727023012024554], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 48, 5.05795574288725, 0.026908092048098214], "isController": false}, {"data": ["500\/Internal Server Error", 889, 93.67755532139094, 0.498360288140819], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 178385, 949, "500\/Internal Server Error", 889, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 48, "400\/Bad Request", 12, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["reserve-384", 22318, 7, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 7, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["reserve-416", 22283, 120, "500\/Internal Server Error", 114, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 4, "400\/Bad Request", 2, null, null, null, null], "isController": false}, {"data": ["reserve-417", 22276, 143, "500\/Internal Server Error", 131, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 10, "400\/Bad Request", 2, null, null, null, null], "isController": false}, {"data": ["reserve-407", 22307, 134, "500\/Internal Server Error", 123, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 9, "400\/Bad Request", 2, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["reserve-403", 22315, 144, "500\/Internal Server Error", 144, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["reserve-415", 22292, 132, "500\/Internal Server Error", 119, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 11, "400\/Bad Request", 2, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": ["reserve-410", 22299, 129, "500\/Internal Server Error", 122, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 5, "400\/Bad Request", 2, null, null, null, null], "isController": false}, {"data": ["reserve-411", 22295, 140, "500\/Internal Server Error", 136, "400\/Bad Request", 2, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException\/Non HTTP response message: Connect to localhost:8081 [localhost\\\/127.0.0.1, localhost\\\/0:0:0:0:0:0:0:1] failed: Connection refused (Connection refused)", 2, null, null, null, null], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
